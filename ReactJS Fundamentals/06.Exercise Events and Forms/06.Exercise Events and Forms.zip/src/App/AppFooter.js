import React from 'react';

const AppFooter = () => "";

export default AppFooter;