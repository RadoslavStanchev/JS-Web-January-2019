interface Movie {
    id: number;
    poster_path: string;
    title: string;
    release_date: string;
}

export default Movie;